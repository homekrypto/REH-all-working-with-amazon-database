export default function HomePage() {
  return (
    <div>
      <h1>Real Estate Website</h1>
      <p>This is working!</p>
    </div>
  )
}
