import PointsSystem from '@/components/gamification/points-system'

export default function RewardsPage() {
  return <PointsSystem />
}