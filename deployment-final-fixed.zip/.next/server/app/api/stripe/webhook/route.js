(()=>{var e={};e.id=3287,e.ids=[3287],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:e=>{"use strict";e.exports=require("dns")},21111:(e,t,r)=>{"use strict";r.d(t,{g:()=>a});var s=r(49526);class i{constructor(e){let t=e||{host:process.env.SMTP_HOST||"localhost",port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER||"",pass:process.env.SMTP_PASS||""}};this.transporter=s.createTransport(t)}async sendEmail(e){try{let t={from:process.env.EMAIL_FROM||"noreply@realestateplatform.com",to:e.to,subject:e.subject,html:e.html,text:e.text||this.stripHtml(e.html)};return await this.transporter.sendMail(t),!0}catch(e){return console.error("Failed to send email:",e),!1}}async sendVerificationEmail(e,t,r){let s=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/api/auth/verify-email?token=${r}`,i=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Verify Your Email</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Thank you for registering with our platform. To complete your registration, please verify your email address by clicking the button below:</p>
              
              <div style="text-align: center;">
                <a href="${s}" class="button">Verify Email Address</a>
              </div>
              
              <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
              <p style="word-break: break-all; color: #3b82f6;">${s}</p>
              
              <p><strong>This link will expire in 24 hours.</strong></p>
              
              <p>If you didn't create an account with us, please ignore this email.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Verify Your Email Address - Real Estate Platform",html:i})}async sendWelcomeEmail(e,t,r){let s=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/dashboard`,i=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to Real Estate Platform</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Your email has been verified and your account is now active!</p>
              
              <p><strong>Account Type:</strong> ${r}</p>
              <p>${{USER:"You can now browse properties and connect with agents.",AGENT:"You can now manage your listings and connect with potential clients.",EXPERT:"You now have access to premium marketing tools and AI-powered features."}[r]||"Welcome to our platform!"}</p>
              
              <div style="text-align: center;">
                <a href="${s}" class="button">Go to Dashboard</a>
              </div>
              
              <p>Here are some things you can do next:</p>
              <ul>
                ${"USER"===r?`
                  <li>Browse available properties</li>
                  <li>Save your favorite listings</li>
                  <li>Contact agents directly</li>
                `:"AGENT"===r?`
                  <li>Create your first property listing</li>
                  <li>Set up your agent profile</li>
                  <li>Start connecting with potential buyers</li>
                `:`
                  <li>Create premium property listings</li>
                  <li>Access AI-powered marketing tools</li>
                  <li>Set up automated social media posting</li>
                  <li>Configure your lead capture forms</li>
                `}
              </ul>
              
              <p>If you have any questions or need help getting started, don't hesitate to reach out to our support team.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Welcome to Real Estate Platform - Account Activated!",html:i})}stripHtml(e){return e.replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim()}}let a=new i},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},43953:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>R,routeModule:()=>y,serverHooks:()=>T,workAsyncStorage:()=>x,workUnitAsyncStorage:()=>v});var s={};r.r(s),r.d(s,{POST:()=>m});var i=r(96559),a=r(48088),o=r(37719),n=r(32190),c=r(97877),d=r(83027),l=r(21111);let u=()=>{let e=process.env.STRIPE_SECRET_KEY;if(!e)throw Error("STRIPE_SECRET_KEY is not configured");return new c.A(e,{apiVersion:"2025-07-30.basil"})},p=process.env.STRIPE_WEBHOOK_SECRET;async function m(e){try{let t,r=await e.text(),s=e.headers.get("stripe-signature");if(!s)return n.NextResponse.json({error:"Missing stripe-signature header"},{status:400});try{t=u().webhooks.constructEvent(r,s,p)}catch(e){return console.error("Webhook signature verification failed:",e),n.NextResponse.json({error:"Invalid signature"},{status:400})}switch(t.type){case"checkout.session.completed":await h(t.data.object);break;case"customer.subscription.created":await b(t.data.object);break;case"customer.subscription.updated":await g(t.data.object);break;case"customer.subscription.deleted":await E(t.data.object);break;case"invoice.payment_succeeded":await f(t.data.object);break;case"invoice.payment_failed":await w(t.data.object);break;default:console.log(`Unhandled event type: ${t.type}`)}return n.NextResponse.json({received:!0})}catch(e){return console.error("Webhook error:",e),n.NextResponse.json({error:"Webhook handler failed"},{status:500})}}async function h(e){try{console.log("Checkout session completed:",e.id);let t=e.metadata?.userId,r=e.metadata?.packageId;if(!t||!r)return void console.error("Missing metadata in checkout session:",e.id);let s=e.subscription,i=u(),a=await i.subscriptions.retrieve(s);await d.db.$executeRaw`
      UPDATE User 
      SET subscriptionStatus = 'ACTIVE',
          packageId = ${r},
          subscriptionEnd = ${new Date(1e3*a.current_period_end)}
      WHERE id = ${t}
    `;let o=await d.db.$queryRaw`
      SELECT email, name, role FROM "User" WHERE id = ${t} LIMIT 1
    `;if(o&&o[0]){let e=o[0];await l.g.sendWelcomeEmail(e.email,e.name,e.role)}console.log(`User ${t} subscription activated successfully`)}catch(e){console.error("Error handling checkout session completed:",e)}}async function b(e){try{console.log("Subscription created:",e.id);let t=e.metadata?.userId;if(!t)return void console.error("Missing userId in subscription metadata:",e.id);await d.db.$executeRaw`
      UPDATE User 
      SET subscriptionStatus = 'ACTIVE',
          subscriptionEnd = ${new Date(1e3*e.current_period_end)}
      WHERE id = ${t}
    `,console.log(`User ${t} subscription created and activated`)}catch(e){console.error("Error handling subscription created:",e)}}async function g(e){try{console.log("Subscription updated:",e.id);let t=e.metadata?.userId;if(!t)return void console.error("Missing userId in subscription metadata:",e.id);let r="ACTIVE";switch(e.status){case"active":r="ACTIVE";break;case"canceled":case"incomplete_expired":r="CANCELED";break;case"past_due":case"unpaid":r="EXPIRED";break;default:r="PENDING"}let s=e.metadata?.packageId,i=e.metadata?.targetRole;s&&i?(await d.db.$executeRaw`
        UPDATE User 
        SET subscriptionStatus = ${r},
            subscriptionEnd = ${new Date(1e3*e.current_period_end)},
            packageId = ${s},
            role = ${i}
        WHERE id = ${t}
      `,console.log(`User ${t} upgraded to ${i} with package ${s}`)):await d.db.$executeRaw`
        UPDATE User 
        SET subscriptionStatus = ${r},
            subscriptionEnd = ${new Date(1e3*e.current_period_end)}
        WHERE id = ${t}
      `,console.log(`User ${t} subscription updated to ${r}`)}catch(e){console.error("Error handling subscription updated:",e)}}async function E(e){try{console.log("Subscription deleted:",e.id);let t=e.metadata?.userId;if(!t)return void console.error("Missing userId in subscription metadata:",e.id);await d.db.$executeRaw`
      UPDATE User 
      SET subscriptionStatus = 'CANCELED',
          subscriptionEnd = ${new Date(1e3*e.ended_at)}
      WHERE id = ${t}
    `,console.log(`User ${t} subscription canceled`)}catch(e){console.error("Error handling subscription deleted:",e)}}async function f(e){try{if(console.log("Invoice payment succeeded:",e.id),e.subscription){let t=u(),r=await t.subscriptions.retrieve(e.subscription),s=r.metadata?.userId;s&&(await d.db.$executeRaw`
          UPDATE User 
          SET subscriptionStatus = 'ACTIVE',
              subscriptionEnd = ${new Date(1e3*r.current_period_end)}
          WHERE id = ${s}
        `,console.log(`User ${s} subscription renewed via payment`))}}catch(e){console.error("Error handling invoice payment succeeded:",e)}}async function w(e){try{if(console.log("Invoice payment failed:",e.id),e.subscription){let t=u(),r=await t.subscriptions.retrieve(e.subscription),s=r.metadata?.userId;if(s){await d.db.$executeRaw`
          UPDATE User 
          SET subscriptionStatus = 'EXPIRED'
          WHERE id = ${s}
        `,console.log(`User ${s} subscription marked as expired due to payment failure`);let e=await d.db.$queryRaw`
          SELECT email, name FROM "User" WHERE id = ${s} LIMIT 1
        `;if(e&&e[0]){let t=e[0];console.log(`Should send payment failed email to ${t.email}`)}}}}catch(e){console.error("Error handling invoice payment failed:",e)}}let y=new i.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/stripe/webhook/route",pathname:"/api/stripe/webhook",filename:"route",bundlePath:"app/api/stripe/webhook/route"},resolvedPagePath:"/Users/michalbabula/Documents/webiste/REH/REH-all-working-with-amazon-database/src/app/api/stripe/webhook/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:x,workUnitAsyncStorage:v,serverHooks:T}=y;function R(){return(0,o.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:v})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},83027:(e,t,r)=>{"use strict";t.db=void 0;let s=r(96330);t.db=globalThis.prisma??new s.PrismaClient({log:["query"]})},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96330:e=>{"use strict";e.exports=require("@prisma/client")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4243,580,9526,7877],()=>r(43953));module.exports=s})();