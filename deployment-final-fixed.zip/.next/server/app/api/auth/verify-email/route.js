(()=>{var e={};e.id=3887,e.ids=[3887],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:e=>{"use strict";e.exports=require("dns")},21111:(e,t,r)=>{"use strict";r.d(t,{g:()=>a});var i=r(49526);class s{constructor(e){let t=e||{host:process.env.SMTP_HOST||"localhost",port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER||"",pass:process.env.SMTP_PASS||""}};this.transporter=i.createTransport(t)}async sendEmail(e){try{let t={from:process.env.EMAIL_FROM||"noreply@realestateplatform.com",to:e.to,subject:e.subject,html:e.html,text:e.text||this.stripHtml(e.html)};return await this.transporter.sendMail(t),!0}catch(e){return console.error("Failed to send email:",e),!1}}async sendVerificationEmail(e,t,r){let i=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/api/auth/verify-email?token=${r}`,s=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Verify Your Email</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Thank you for registering with our platform. To complete your registration, please verify your email address by clicking the button below:</p>
              
              <div style="text-align: center;">
                <a href="${i}" class="button">Verify Email Address</a>
              </div>
              
              <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
              <p style="word-break: break-all; color: #3b82f6;">${i}</p>
              
              <p><strong>This link will expire in 24 hours.</strong></p>
              
              <p>If you didn't create an account with us, please ignore this email.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Verify Your Email Address - Real Estate Platform",html:s})}async sendWelcomeEmail(e,t,r){let i=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/dashboard`,s=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to Real Estate Platform</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Your email has been verified and your account is now active!</p>
              
              <p><strong>Account Type:</strong> ${r}</p>
              <p>${{USER:"You can now browse properties and connect with agents.",AGENT:"You can now manage your listings and connect with potential clients.",EXPERT:"You now have access to premium marketing tools and AI-powered features."}[r]||"Welcome to our platform!"}</p>
              
              <div style="text-align: center;">
                <a href="${i}" class="button">Go to Dashboard</a>
              </div>
              
              <p>Here are some things you can do next:</p>
              <ul>
                ${"USER"===r?`
                  <li>Browse available properties</li>
                  <li>Save your favorite listings</li>
                  <li>Contact agents directly</li>
                `:"AGENT"===r?`
                  <li>Create your first property listing</li>
                  <li>Set up your agent profile</li>
                  <li>Start connecting with potential buyers</li>
                `:`
                  <li>Create premium property listings</li>
                  <li>Access AI-powered marketing tools</li>
                  <li>Set up automated social media posting</li>
                  <li>Configure your lead capture forms</li>
                `}
              </ul>
              
              <p>If you have any questions or need help getting started, don't hesitate to reach out to our support team.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Welcome to Real Estate Platform - Account Activated!",html:s})}stripHtml(e){return e.replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim()}}let a=new s},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},44801:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>g,routeModule:()=>p,serverHooks:()=>f,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>h});var i={};r.r(i),r.d(i,{GET:()=>d,POST:()=>c});var s=r(96559),a=r(48088),o=r(37719),n=r(32190),l=r(83027),u=r(21111);async function d(e){try{let{searchParams:t}=new URL(e.url),r=t.get("token");if(!r)return n.NextResponse.json({error:"Verification token is required"},{status:400});let i=await l.db.emailVerification.findUnique({where:{token:r},include:{user:!0}});if(!i)return n.NextResponse.json({error:"Invalid or expired verification token"},{status:400});if((new Date().getTime()-i.createdAt.getTime())/36e5>24)return await l.db.emailVerification.delete({where:{id:i.id}}),n.NextResponse.json({error:"Verification token has expired. Please request a new one."},{status:400});if(i.user.emailVerified)return await l.db.emailVerification.delete({where:{id:i.id}}),n.NextResponse.json({success:!0,message:"Email is already verified",alreadyVerified:!0},{status:200});let s=await l.db.user.update({where:{id:i.userId},data:{emailVerified:new Date},select:{id:!0,email:!0,name:!0,role:!0,subscriptionStatus:!0,packageId:!0}});await l.db.emailVerification.delete({where:{id:i.id}}),s.email&&await u.g.sendWelcomeEmail(s.email,s.name||"",s.role);let a="/dashboard",o=!1;return"USER"!==s.role&&"PENDING"===s.subscriptionStatus&&(o=!0,a="/complete-registration"),n.NextResponse.json({success:!0,message:"Email verified successfully!",user:{id:s.id,email:s.email,name:s.name,role:s.role,subscriptionStatus:s.subscriptionStatus},needsPayment:o,nextStep:a},{status:200})}catch(e){return console.error("Email verification error:",e),n.NextResponse.json({error:"Internal server error. Please try again."},{status:500})}}async function c(e){try{let{email:t}=await e.json();if(!t)return n.NextResponse.json({error:"Email is required"},{status:400});let r=await l.db.user.findUnique({where:{email:t}});if(!r)return n.NextResponse.json({error:"User not found"},{status:404});if(r.emailVerified)return n.NextResponse.json({error:"Email is already verified"},{status:400});await l.db.emailVerification.deleteMany({where:{userId:r.id}});let i=crypto.randomUUID();if(await l.db.emailVerification.create({data:{userId:r.id,token:i,expiresAt:new Date(Date.now()+864e5)}}),!await u.g.sendVerificationEmail(r.email,r.name,i))return n.NextResponse.json({error:"Failed to send verification email. Please try again."},{status:500});return n.NextResponse.json({success:!0,message:"Verification email sent successfully"},{status:200})}catch(e){return console.error("Resend verification error:",e),n.NextResponse.json({error:"Internal server error. Please try again."},{status:500})}}let p=new s.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/auth/verify-email/route",pathname:"/api/auth/verify-email",filename:"route",bundlePath:"app/api/auth/verify-email/route"},resolvedPagePath:"/Users/michalbabula/Documents/webiste/REH/REH-all-working-with-amazon-database/src/app/api/auth/verify-email/route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:m,workUnitAsyncStorage:h,serverHooks:f}=p;function g(){return(0,o.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:h})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},83027:(e,t,r)=>{"use strict";t.db=void 0;let i=r(96330);t.db=globalThis.prisma??new i.PrismaClient({log:["query"]})},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96330:e=>{"use strict";e.exports=require("@prisma/client")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[4243,580,9526],()=>r(44801));module.exports=i})();