(()=>{var e={};e.id=1612,e.ids=[1612],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5069:(e,t,r)=>{"use strict";r.d(t,{db:()=>a});var s=r(96330);let a=globalThis.prisma??new s.PrismaClient({log:["query"]})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:e=>{"use strict";e.exports=require("dns")},21111:(e,t,r)=>{"use strict";r.d(t,{g:()=>i});var s=r(49526);class a{constructor(e){let t=e||{host:process.env.SMTP_HOST||"localhost",port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER||"",pass:process.env.SMTP_PASS||""}};this.transporter=s.createTransport(t)}async sendEmail(e){try{let t={from:process.env.EMAIL_FROM||"noreply@realestateplatform.com",to:e.to,subject:e.subject,html:e.html,text:e.text||this.stripHtml(e.html)};return await this.transporter.sendMail(t),!0}catch(e){return console.error("Failed to send email:",e),!1}}async sendVerificationEmail(e,t,r){let s=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/api/auth/verify-email?token=${r}`,a=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Verify Your Email</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Thank you for registering with our platform. To complete your registration, please verify your email address by clicking the button below:</p>
              
              <div style="text-align: center;">
                <a href="${s}" class="button">Verify Email Address</a>
              </div>
              
              <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
              <p style="word-break: break-all; color: #3b82f6;">${s}</p>
              
              <p><strong>This link will expire in 24 hours.</strong></p>
              
              <p>If you didn't create an account with us, please ignore this email.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Verify Your Email Address - Real Estate Platform",html:a})}async sendWelcomeEmail(e,t,r){let s=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/dashboard`,a=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to Real Estate Platform</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to Real Estate Platform!</h1>
            </div>
            <div class="content">
              <h2>Hi ${t},</h2>
              <p>Your email has been verified and your account is now active!</p>
              
              <p><strong>Account Type:</strong> ${r}</p>
              <p>${{USER:"You can now browse properties and connect with agents.",AGENT:"You can now manage your listings and connect with potential clients.",EXPERT:"You now have access to premium marketing tools and AI-powered features."}[r]||"Welcome to our platform!"}</p>
              
              <div style="text-align: center;">
                <a href="${s}" class="button">Go to Dashboard</a>
              </div>
              
              <p>Here are some things you can do next:</p>
              <ul>
                ${"USER"===r?`
                  <li>Browse available properties</li>
                  <li>Save your favorite listings</li>
                  <li>Contact agents directly</li>
                `:"AGENT"===r?`
                  <li>Create your first property listing</li>
                  <li>Set up your agent profile</li>
                  <li>Start connecting with potential buyers</li>
                `:`
                  <li>Create premium property listings</li>
                  <li>Access AI-powered marketing tools</li>
                  <li>Set up automated social media posting</li>
                  <li>Configure your lead capture forms</li>
                `}
              </ul>
              
              <p>If you have any questions or need help getting started, don't hesitate to reach out to our support team.</p>
              
              <p>Best regards,<br>The Real Estate Platform Team</p>
            </div>
            <div class="footer">
              <p>This email was sent to ${e}. If you have any questions, please contact our support team.</p>
            </div>
          </div>
        </body>
      </html>
    `;return this.sendEmail({to:e,subject:"Welcome to Real Estate Platform - Account Activated!",html:a})}stripHtml(e){return e.replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim()}}let i=new a},21820:e=>{"use strict";e.exports=require("os")},23870:(e,t,r)=>{"use strict";r.d(t,{A:()=>l});var s=r(55511);let a={randomUUID:s.randomUUID},i=new Uint8Array(256),o=i.length,n=[];for(let e=0;e<256;++e)n.push((e+256).toString(16).slice(1));let l=function(e,t,r){if(a.randomUUID&&!t&&!e)return a.randomUUID();let l=(e=e||{}).random??e.rng?.()??(o>i.length-16&&((0,s.randomFillSync)(i),o=0),i.slice(o,o+=16));if(l.length<16)throw Error("Random bytes length must be >= 16");if(l[6]=15&l[6]|64,l[8]=63&l[8]|128,t){if((r=r||0)<0||r+16>t.length)throw RangeError(`UUID byte range ${r}:${r+15} is out of buffer bounds`);for(let e=0;e<16;++e)t[r+e]=l[e];return t}return function(e,t=0){return(n[e[t+0]]+n[e[t+1]]+n[e[t+2]]+n[e[t+3]]+"-"+n[e[t+4]]+n[e[t+5]]+"-"+n[e[t+6]]+n[e[t+7]]+"-"+n[e[t+8]]+n[e[t+9]]+"-"+n[e[t+10]]+n[e[t+11]]+n[e[t+12]]+n[e[t+13]]+n[e[t+14]]+n[e[t+15]]).toLowerCase()}(l)}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94625:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>h,serverHooks:()=>x,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>f});var s={};r.r(s),r.d(s,{POST:()=>m});var a=r(96559),i=r(48088),o=r(37719),n=r(32190),l=r(85665),c=r.n(l),u=r(5069),p=r(21111),d=r(23870);async function m(e){try{let{email:t,password:r,name:s,role:a="USER",phone:i,agencyName:o,bio:l,packageId:m}=await e.json();if(!t||!r||!s)return n.NextResponse.json({error:"Email, password, and name are required"},{status:400});if(!["USER","AGENT","EXPERT"].includes(a))return n.NextResponse.json({error:"Invalid role specified"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t))return n.NextResponse.json({error:"Invalid email format"},{status:400});if(r.length<6)return n.NextResponse.json({error:"Password must be at least 6 characters long"},{status:400});if("USER"!==a&&!m)return n.NextResponse.json({error:"Package selection is required for Agent and Expert accounts"},{status:400});if(m){if(!await u.db.package.findUnique({where:{id:m,active:!0}}))return n.NextResponse.json({error:"Invalid package selected"},{status:400});if("AGENT"===a&&!m.includes("agent"))return n.NextResponse.json({error:"Selected package is not compatible with Agent role"},{status:400});if("EXPERT"===a&&!m.includes("expert"))return n.NextResponse.json({error:"Selected package is not compatible with Expert role"},{status:400})}if(await u.db.user.findUnique({where:{email:t}}))return n.NextResponse.json({error:"An account with this email already exists"},{status:409});let h=await c().hash(r,12),g="FREE";"USER"!==a&&(g="PENDING");let f=await u.db.user.create({data:{email:t,passwordHash:h,name:s,role:a,phone:i||null,agencyName:"USER"!==a&&o?o:null,bio:"USER"!==a&&l?l:null,packageId:m||null,subscriptionStatus:g,emailVerified:null},select:{id:!0,email:!0,name:!0,role:!0,phone:!0,agencyName:!0,bio:!0,packageId:!0,subscriptionStatus:!0,createdAt:!0}}),x=(0,d.A)();await u.db.emailVerification.create({data:{userId:f.id,token:x,expiresAt:new Date(Date.now()+864e5)}}),await p.g.sendVerificationEmail(f.email,f.name,x)||console.error("Failed to send verification email for user:",f.email);let y="USER"===a?"Free account created successfully! You can now sign in.":"Account created successfully! Please check your email to verify your account and complete the payment process.";return n.NextResponse.json({success:!0,message:y,user:f,needsPayment:"USER"!==a,needsEmailVerification:!0},{status:201})}catch(e){return console.error("Registration error:",e),n.NextResponse.json({error:"Internal server error. Please try again."},{status:500})}}let h=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/auth/register/route",pathname:"/api/auth/register",filename:"route",bundlePath:"app/api/auth/register/route"},resolvedPagePath:"/Users/michalbabula/Documents/webiste/REH/REH-all-working-with-amazon-database/src/app/api/auth/register/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:g,workUnitAsyncStorage:f,serverHooks:x}=h;function y(){return(0,o.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:f})}},94735:e=>{"use strict";e.exports=require("events")},96330:e=>{"use strict";e.exports=require("@prisma/client")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4243,580,5665,9526],()=>r(94625));module.exports=s})();